---
fileClass: GeneralTest
testCaseId: PBM13
testTags:
componente: [PBM]
view: PBM-Übersicht-Screen
vorbedingung: Ein bestehendes BEGA Smartsystem wurde geteilt;
---

| Referenz | Ausgangspunkt | Vorgang | Erwartetes Verhalten |
| :-- | :-- | :-- | :-- |
| **`= this.testCaseId`**.1 | PBM-Übersicht-Screen |  | Schaltflächen zum Konfigurieren der Eingänge ausgeblendet |
| **`= this.testCaseId`**.2 | PBM-Übersicht-Screen |  | Schaltflächen Clone-Settings ausgeblendet |
