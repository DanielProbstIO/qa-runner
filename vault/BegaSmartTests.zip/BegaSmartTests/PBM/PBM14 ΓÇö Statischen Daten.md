---
fileClass: GeneralTest
testCaseId: PBM14
testTags:
componente: [PBM]
view:
vorbedingung:
---

Prüfen der Statischen Daten anhand Anforderungsdokument