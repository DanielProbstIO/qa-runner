---
fileClass: GeneralTest
testCaseId: PBM15
testTags:
componente: [PBM]
view:
vorbedingung:
---
Prüfen der UI-Strings anhand Anforderungsdokument
